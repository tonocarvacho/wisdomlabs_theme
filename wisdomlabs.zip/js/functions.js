$('#element').click(function() {
   if($('#radio_button').is(':checked')) { alert("it's checked"); }
});
(jQuery);


