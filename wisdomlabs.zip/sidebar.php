<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WisdomLabs
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>

<aside id="secondary" class="widget-area">

		<div class="sidebarlinks">
			<div class="sidecall">
				<h2>Contactenos y solicite tu cotizacion.</h2>
				<a href="#" class="linebtn btncolorfooter">CONTACTARSE</a>
			</div>

			<article class="bloque-articulo">
				
					<img src="<?php echo bloginfo('template_url');?>/images/img1.jpg">
				
					<div class="entry-info">
				
							<h3 class="entry-title">SPLIT MURO</h3>
								
							
				
					
						
				
					</div><!-- .entry-info -->
			</article>

			<article class="bloque-articulo">
				
					<img src="<?php echo bloginfo('template_url');?>/images/img2.jpg">
				
					<div class="entry-info">
						
							<h3 class="entry-title">PORTATIL</h3>
								
						
					
					
					</div><!-- .entry-info -->
			</article>

			<article class="bloque-articulo">
				
					<img src="<?php echo bloginfo('template_url');?>/images/img3.jpg">
				
					<div class="entry-info">
						
							<h3 class="entry-title">DUCTO</h3>
								
							
				
					
					
				
					</div><!-- .entry-info -->
			</article>
			<article class="bloque-articulo">
				
					<img src="<?php echo bloginfo('template_url');?>/images/img3.jpg">
				
					<div class="entry-info">
					
							<h3 class="entry-title">PISO CIELO</h3>
								
							
					
					
						
					
					</div><!-- .entry-info -->
			</article>
			<article class="bloque-articulo">
				
					<img src="<?php echo bloginfo('template_url');?>/images/img3.jpg">
				
					<div class="entry-info">
						
							<h3 class="entry-title">CASETTE</h3>
								
					
					
					
					</div><!-- .entry-info -->
			</article>
			<article class="bloque-articulo">
				
					<img src="<?php echo bloginfo('template_url');?>/images/img3.jpg">
				
					<div class="entry-info">
						
							<h3 class="entry-title">ACCESORIOS</h3>
								
			
					</div><!-- .entry-info -->
			</article>

			<article>
			<?php dynamic_sidebar( 'sidebar-1' ); ?>
			</article>

		</div>
	
</aside><!-- #secondary -->
