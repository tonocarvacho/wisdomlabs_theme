<?php
/**
 * WisdomLabs Theme Customizer
 *
 * @package WisdomLabs
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function wisdomlabs_customize_register( $wp_customize ) {

	
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	/**
	 * Custom Customizer Customizations
	 */

	// Add option to select index content
	$wp_customize->add_section( 'theme_options', 
		array(
			'title'			=> __( 'Theme Options', 'wisdomlabs' ),
			'priority'		=> 95,
			'capability'	=> 'edit_theme_options',
			'description'	=> __( 'Change how much of a post is displayed on index and archive pages.', 'wisdomlabs' )
		)
	);

	// Custom control
	class fx_Share_Customize_Control_Sortable_Checkboxes extends WP_Customize_Control {
	/**
	 * Control Type
	 */
	public $type = 'fx-share-multicheck-sortable';
	/**
	 * Enqueue Scripts
	 */
	public function enqueue() {
		wp_enqueue_style( 'fx-share-customize' );
		wp_enqueue_script( 'jt-customize-controls', trailingslashit( get_template_directory_uri() ) . '/js/jquery-sortables.js', array( 'jquery' ) );
	}
	/**
	 * Render Settings
	 */
	public function render_content() {
		/* if no choices, bail. */
		if ( empty( $this->choices ) ){
			return;
		} ?>

		<?php if ( !empty( $this->label ) ){ ?>
			<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<?php } // add label if needed. ?>

		<?php if ( !empty( $this->description ) ){ ?>
			<span class="description customize-control-description"><?php echo $this->description; ?></span>
		<?php } // add desc if needed. ?>

		<?php
		/* Data */
		$values = explode( ',', $this->value() );
		$choices = $this->choices;
		/* If values exist, use it. */
		$options = array();
		if( $values ){
			/* get individual item */
			foreach( $values as $value ){
				/* separate item with option */
				$value = explode( ':', $value );
				/* build the array. remove options not listed on choices. */
				if ( array_key_exists( $value[0], $choices ) ){
					$options[$value[0]] = $value[1] ? '1' : '0'; 
				}
			}
		}
		/* if there's new options (not saved yet), add it in the end. */
		foreach( $choices as $key => $val ){
			/* if not exist, add it in the end. */
			if ( ! array_key_exists( $key, $options ) ){
				$options[$key] = '0'; // use zero to deactivate as default for new items.
			}
		}
		?>

		<ul class="fx-share-multicheck-sortable-list">

			<?php foreach ( $options as $key => $value ){ ?>

				<li>
					<label>
						<input name="<?php echo esc_attr( $key ); ?>" class="fx-share-multicheck-sortable-item" type="checkbox" value="<?php echo esc_attr( $value ); ?>" <?php checked( $value ); ?> /> 
						<?php echo esc_html( $choices[$key] ); ?>
					</label>
					<i class="dashicons dashicons-menu fx-share-multicheck-sortable-handle"></i>
				</li>

			<?php } // end choices. ?>

				<li class="fx-share-hideme">
					<input type="hidden" class="fx-share-multicheck-sortable" <?php $this->link(); ?> value="<?php echo esc_attr( $this->value() ); ?>" />
				</li>

		</ul><!-- .fx-share-multicheck-sortable-list -->


	<?php
	}
}

	/* Add Section */
	$wp_customize->add_section(
		'fx_share',
		array(
			'title' => esc_html__( 'Sharing', 'fx-share' ),
		)
	);
	/* === SERVICES === */
	/* Add Settings */
	$wp_customize->add_setting(
		'fx_share[services]', /* option name */
		array(
			'default'           => fx_share_services_default(), // facebook:1,twitter:1,google_plus:1
			'sanitize_callback' => 'fx_share_sanitize_services',
			'transport'         => 'refresh',
			'type'              => 'option',
			'capability'        => 'manage_options',
		)
	);
	/* Add Control for the settings. */
	$choices = array();
	$services = fx_share_services();
	foreach( $services as $key => $val ){
		$choices[$key] = $val['label'];
	}
	$wp_customize->add_control(
		new fx_Share_Customize_Control_Sortable_Checkboxes(
			$wp_customize,
			'fx_share_services', /* control id */
			array(
				'section'     => 'fx_share',
				'settings'    => 'fx_share[services]',
				'label'       => __( 'Sharing Services', 'fx-share' ),
				'description' => __( 'Enable and reorder sharing buttons.', 'fx-share' ),
				'choices'     => $choices,
			)
		)
	);


	// Setting for header and footer background color
	$wp_customize->add_setting( 'theme_bg_color', array(
		'default'			=> '#002254',
		'transport'			=> 'postMessage',
		'type'				=> 'theme_mod',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	
	// Control for header and footer background color.
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'theme_bg_color', 
				array(
					'label'		=> __( 'Header and footer background color', 'wisdomlabs'),
					'section'	=> 'colors',
					'settings'	=> 'theme_bg_color'
				)
		)
	);


	
	// Create interactive color setting
	$wp_customize->add_setting( 'interactive_color' , 
		array(
			'default'			=> '#b51c35',
			'transport'			=> 'postMessage',
			'type'				=> 'theme_mod',
			'sanitize_callback'	=> 'sanitize_hex_color',
			'transport'			=> 'postMessage',
		)
	);
	
	// Add the controls
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'interactive_color', array(
				'label'		=> __( 'Interactive color (links etc)', 'wisdomlabs' ),
				'section'	=> 'colors',
				'settings'	=> 'interactive_color'
			)
		)
	);

	
	
	// Create excerpt or full content settings
	$wp_customize->add_setting(	'length_setting',
		array(
			'default'			=> 'excerpt',
			'type'				=> 'theme_mod',
			'sanitize_callback' => 'wisdomlabs_sanitize_length', // Sanitization function appears further down
			'transport'			=> 'postMessage'
		)
	);

	// Add the controls
	$wp_customize->add_control(	'wisdomlabs_length_control',
		array(
			'type'		=> 'select',
			'label'		=> __( 'Index/archive displays', 'wisdomlabs' ),
			'section'	=> 'theme_options',
			'choices'	=> array(
				'excerpt'		=> __( 'Excerpt (default)', 'wisdomlabs' ),
				'full-content'	=> __( 'Full content', 'wisdomlabs' )
			),
			'settings'	=> 'length_setting' // Matches setting ID from above
		)
	);


	Kirki::add_field( '', array(
	    'type'        => 'sortable',
	    'settings'    => 'single_post_template_parts',
	    'label'       => __( 'Template parts for single posts', 'kirki' ),
	    'description' => __( 'You can enable/disable the template parts that interest you below and reorder them to your 	liking.', 'kirki' ),
	    'section'     => 'theme_options',
	    'default'     => array(
	        'title',
	        'tags',
	        'content'
	    ),
	    'choices'     => array(
	        'title'          => __( 'Title', 'kirki' ),
	        'tags'           => __( 'Tags', 'kirki' ),
	        'featured-image' => __( 'Featured Image', 'kirki' ),
	        'content'        => __( 'Content', 'kirki' ),
	        'author'         => __( 'Author', 'kirki' ),
	        'comments'       => __( 'Comments', 'kirki' ),
	    ),
	    'priority'    => 10,
	) );


}
add_action( 'customize_register', 'wisdomlabs_customize_register' );

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function wisdomlabs_customize_partial_blogname() {
	bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function wisdomlabs_customize_partial_blogdescription() {
	bloginfo( 'description' );
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function wisdomlabs_customize_preview_js() {
	wp_enqueue_script( 'wisdomlabs-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'wisdomlabs_customize_preview_js' );


/**
 * Sanitize length options:
 * If something goes wrong and one of the two specified options are not used,
 * apply the default (excerpt).
 */

function wisdomlabs_sanitize_length( $value ) {
    if ( ! in_array( $value, array( 'excerpt', 'full-content' ) ) ) {
        $value = 'excerpt';
	}
    return $value;
}